# SScript
uh use it if you wanna. you dont need to credit me, just credit guy named is desc

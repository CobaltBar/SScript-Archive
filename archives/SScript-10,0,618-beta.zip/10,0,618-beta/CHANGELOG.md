# 10.0.618-beta
- Added class support
- Removed StringTools support
- Reworked functions
- Reworked finals
- Reworked variable initialization
- Added better check to if, for and while expressions
- Reworked global variables